from django.db import models


class FacultyList(models.Model):
    username = models.CharField(max_length=250)
    password = models.CharField(max_length=100)
