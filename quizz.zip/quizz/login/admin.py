from django.contrib import admin
from .models import LoginList
from .models import RegisterList

admin.site.register(LoginList)
admin.site.register(RegisterList)
