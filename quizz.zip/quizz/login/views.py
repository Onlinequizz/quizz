from django.http import HttpResponse
from django.template import loader
from Register.models import RegisterList


def index(request):
    template = loader.get_template('quizz/index.html')
    context = {}
    return HttpResponse(template.render(context, request))


def home(request):
    email = request.POST.get('username', '')
    password = request.POST.get('password', '')
    print(email+" "+password)
    print("success")
   # if RegisterList.objects.get(name=email):
   #     return HttpResponse('<h1>Login Successful </h1>')
    try:
       details = RegisterList.objects.get(email=str(email))
    except RegisterList.DoesNotExist:

        return HttpResponse('<h1>User name doesnt exists </h1>')
    if details.password == password:
        return HttpResponse('<h1>Login Successful </h1>')
    else:
        return HttpResponse("Wrong Password")

