from django.contrib import admin
from .models import RegisterList

admin.site.register(RegisterList)